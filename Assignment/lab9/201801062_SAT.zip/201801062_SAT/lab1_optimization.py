#!/usr/bin/env python
# coding: utf-8

# In[ ]:


import numpy as np
import matplotlib.pyplot as plt

#only enter Minimize for minimizing and Maximize for Maximizing problems even though the code is only for minimizing!
z = input('Input whether it is a minimizing problem or a maximizing problem:     ')
a, b = input('Input the x and y coeffiecients respectively :  ').split()
a = int(a)
b = int(b)
a1, b1, c1, d1 = input('Enter the first inequality:  ').split()
#the in-equality is a1x + b1y <= c1 or a1x + b1y >= c1
a1 = int(a1)
b1 = int(b1)
c1 = int(c1)
a2, b2, c2, d2 = input('Enter the second inequality:  ').split()
#the in-equality is a2x + b2y <= c2 or a2x + b2y >= c2
a2 = int(a2)
b2 = int(b2)
c2 = int(c2)
a3, b3, c3, d3 = input('Enter the third inequality:  ').split()
#the in-equality is a3x + b3y <= c3 or a3x + b3y >= c3
a3 = int(a3)
b3 = int(b3)
c3 = int(c3)

#Extreme point variables -> ex1_x,ex1_y,ex2_x,ex2_y,ex3_x,ex3_y ,ex4_x,ex4_y,ex5_x,ex5_y,ex6_x,ex6_y,
#ex7_x,ex7_y,ex8_x,ex8_y,ex9_x,ex9_y
# the values of z for extreme points

ex1_x = -1
ex1_y = -1
ex2_x = -1
ex2_y = -1
ex3_x = -1
ex3_y = -1
ex4_x = -1
ex4_y = -1
ex5_x = -1
ex5_y = -1
ex6_x = -1
ex6_y = -1
ex7_x = -1
ex7_y = -1
ex8_x = -1
ex8_y = -1
ex9_x = -1
ex9_y = -1
value1 = 9999
value2 = 9999
value3 = 9999
value4 = 9999
value5 = 9999
value6 = 9999
value7 = 9999
value8 = 9999
value9 = 9999
value10 = 9999
max1 = 9999
index = 0
multi = 0

if((a1*b2 - a2*b1) != 0):
    ex1_y = (c1*a2 - c2*a1)/( -a1*b2 + a2*b1);
    ex1_x = (c1*b2 - c2*b1)/(a1*b2 - a2*b1);

if((a3*b2 - a2*b3) != 0):
    ex2_y = (c3*a2 - c2*a3)/( -a3*b2 + a2*b3);
    ex2_x = (c3*b2 - c2*b3)/(a3*b2 - a2*b3);
    if(ex2_y == ex1_y and ex2_x == ex1_x):
        ex2_y = -1;
        ex2_x = -1;

if((a1*b3 - a3*b1) != 0):
    ex3_y = (c1*a3 - c3*a1)/( -a1*b3 + a3*b1);
    ex3_x = (c1*b3 - c3*b1)/(a1*b3 - a3*b1);
    if((ex3_y == ex1_y and ex3_x == ex1_x) or (ex3_y == ex2_y and ex3_x == ex2_x)):
        ex3_y = -1;
        ex3_x = -1;

if(a1 != 0):
    ex4_x = c1/a1;
    ex4_y = 0;
    if((ex4_y == ex1_y and ex4_x == ex1_x) or (ex4_y == ex2_y and ex4_x == ex2_x) 
       or (ex3_y == ex4_y and ex3_x == ex4_x)):
        ex3_y = -1;
        ex3_x = -1;

if(b1 != 0):
    ex5_y = c1/b1;
    ex5_x = 0;
    if((ex5_y == ex1_y and ex5_x == ex1_x) or (ex5_y == ex2_y and ex5_x == ex2_x) 
       or (ex3_y == ex5_y and ex3_x == ex5_x) or (ex5_y == ex4_y and ex5_x == ex4_x)):
        ex3_y = -1;
        ex3_x = -1;

if(a2 != 0):
    ex6_x = c2/a2;
    ex6_y = 0;
    if((ex6_y == ex1_y and ex6_x == ex1_x) or (ex6_y == ex2_y and ex6_x == ex2_x) 
       or (ex3_y == ex6_y and ex3_x == ex6_x)or (ex6_y == ex4_y and ex6_x == ex4_x) 
       or (ex6_y == ex5_y and ex6_x == ex5_x)):
        ex3_y = -1;
        ex3_x = -1;

if(b2 != 0):
    ex7_y = c2/b2;
    ex7_x = 0;
    if((ex7_y == ex1_y and ex7_x == ex1_x) or (ex7_y == ex2_y and ex7_x == ex2_x)
      or (ex3_y == ex7_y and ex3_x == ex7_x) or (ex7_y == ex4_y and ex7_x == ex4_x)
      or (ex7_y == ex5_y and ex7_x == ex5_x) or (ex7_y == ex6_y and ex7_x == ex6_x)):
        ex3_y = -1;
        ex3_x = -1;

if(a3 != 0):
    ex8_x = c3/a3;
    ex8_y = 0;
    if((ex8_y == ex7_y and ex8_x == ex7_x) or (ex8_y == ex1_y and ex8_x == ex1_x) 
       or (ex8_y == ex2_y and ex8_x == ex2_x) or (ex3_y == ex8_y and ex3_x == ex8_x) 
       or (ex8_y == ex4_y and ex8_x == ex4_x) or (ex8_y == ex5_y and ex8_x == ex5_x) 
       or (ex8_y == ex6_y and ex6_x == ex8_x)):
        ex3_y = -1;
        ex3_x = -1;

if(b3 != 0):
    ex9_y = c3/b3;
    ex9_x = 0;
    if((ex9_y == ex8_y and ex9_x == ex8_x) or (ex9_y == ex7_y and ex9_x == ex7_x)
       or (ex9_y == ex1_y and ex9_x == ex1_x) or (ex9_y == ex2_y and ex9_x == ex2_x)
       or (ex3_y == ex9_y and ex3_x == ex9_x) or (ex9_y == ex4_y and ex9_x == ex4_x)
       or (ex9_y == ex5_y and ex9_x == ex5_x) or (ex9_y == ex6_y and ex9_x == ex6_x)):
        ex3_y = -1;
        ex3_x = -1;

# Construct lines
x = np.linspace(0, 100, 2000)
y = np.linspace(0, 100, 2000)

#all the possible conditions!!
if ((d1 == 'leq') and (d2 == 'leq') and (d3 == 'leq')): 
    #graph
    # x >= 0
    x1 = (y*0) + 0
    # y >= 0
    y1 = (x*0) + 0
    # b1y <= a1x + c1 
    y2 = (c1 - (a1 * x))/b1
    # b2y <= a2x + c2 
    y3 = (c2 - (a2 * x))/b2
    # a3y <= b3x + c3 
    y4 = (c3 - (a3 * x))/b3
    plt.figure()
    plt.title('The graph of the LPP')
    plt.style.use('seaborn-whitegrid')
    plt.plot(x1, y, label=r'$x\geq0$')
    plt.plot(x, y1, label=r'$y\geq0$')
    plt.plot(x, y2, label= r'%dx + %dy $\leq$ %d' %(a1, b1, c1))
    plt.plot(x, y3, label= r'%dx + %dy $\leq$ %d' %(a2, b2, c2))
    plt.plot(x, y4, label= r'%dx + %dy $\leq$ %d' %(a3, b3, c3))
    plt.xlim((0, 100))
    plt.ylim((0, 100))
    plt.xlabel(r'$x$')
    plt.ylabel(r'$y$')
    #graph ends
    
    # Fill feasible region
    y5 = np.minimum(y2, y4)
    y5 = np.minimum(y5, y3)
    y6 = 0
    plt.fill_between(x, y5, y6, where=y5>y6, color='grey', alpha=0.3)
    plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
    #extreme point analysis
    
    if((((a1*(ex1_x)) + (b1*(ex1_y))) <= c1) and 
       (((a2*(ex1_x)) + (b2*(ex1_y))) <= c2) and 
       (((a3*(ex1_x)) + (b3*(ex1_y))) <= c3) and 
       (ex1_x >= 0) and (ex1_y >= 0)):
        value1 = (a*(ex1_x) + b*(ex1_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex1_x,ex1_y,value1))
        
    if((((a1*(ex2_x)) + (b1*(ex2_y))) <= c1) and 
       (((a2*(ex2_x)) + (b2*(ex2_y))) <= c2) and 
       (((a3*(ex2_x)) + (b3*(ex2_y))) <= c3) and 
       (ex2_x >= 0) and (ex2_y >= 0)):
        value2 = (a*(ex2_x) + b*(ex2_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex2_x,ex2_y,value2))
        
    if((((a1*(ex3_x)) + (b1*(ex3_y))) <= c1) and 
       (((a2*(ex3_x)) + (b2*(ex3_y))) <= c2) and 
       (((a3*(ex3_x)) + (b3*(ex3_y))) <= c3) and 
       (ex3_x >= 0) and (ex3_y >= 0)):
        value3 = (a*(ex3_x) + b*(ex3_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex3_x,ex3_y,value3))
        
    if((((a1*(ex4_x)) + (b1*(ex4_y))) <= c1) and 
       (((a2*(ex4_x)) + (b2*(ex4_y))) <= c2) and 
       (((a3*(ex4_x)) + (b3*(ex4_y))) <= c3) and 
       (ex4_x >= 0) and (ex4_y >= 0)):
        value4 = (a*(ex4_x) + b*(ex4_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex4_x,ex4_y,value4))
        
    if((((a1*(ex5_x)) + (b1*(ex5_y))) <= c1) and 
       (((a2*(ex5_x)) + (b2*(ex5_y))) <= c2) and 
       (((a3*(ex5_x)) + (b3*(ex5_y))) <= c3) and 
       (ex5_x >= 0) and (ex5_y >= 0)):
        value5 = (a*(ex5_x) + b*(ex5_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex5_x,ex5_y,value5))
        
    if((((a1*(ex6_x)) + (b1*(ex6_y))) <= c1) and 
       (((a2*(ex6_x)) + (b2*(ex6_y))) <= c2) and 
       (((a3*(ex6_x)) + (b3*(ex6_y))) <= c3) and 
       (ex6_x >= 0) and (ex6_y >= 0)):
        value6 = (a*(ex6_x) + b*(ex6_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex6_x,ex6_y,value6))
        
    if((((a1*(ex7_x)) + (b1*(ex7_y))) <= c1) and 
       (((a2*(ex7_x)) + (b2*(ex7_y))) <= c2) and 
       (((a3*(ex7_x)) + (b3*(ex7_y))) <= c3) and 
       (ex7_x >= 0) and (ex7_y >= 0)):
        value7 = (a*(ex7_x) + b*(ex7_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex7_x,ex7_y,value7))
        
    if((((a1*(ex8_x)) + (b1*(ex8_y))) <= c1) and 
       (((a2*(ex8_x)) + (b2*(ex8_y))) <= c2) and 
       (((a3*(ex8_x)) + (b3*(ex8_y))) <= c3) and 
       (ex8_x >= 0) and (ex8_y >= 0)):
        value8 = (a*(ex8_x) + b*(ex8_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex8_x,ex8_y,value8))
        
    if((((a1*(ex9_x)) + (b1*(ex9_y))) <= c1) and 
       (((a2*(ex9_x)) + (b2*(ex9_y))) <= c2) and 
       (((a3*(ex9_x)) + (b3*(ex9_y))) <= c3) and 
       (ex9_x >= 0) and (ex9_y >= 0)):
        value9 = (a*(ex9_x) + b*(ex9_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex9_x,ex9_y,value9))
        
    if(c1>=0 and c2>=0 and c3>=0):
        value10 = 0
        print("Extreme points: (0,0) Value: 0")
        
    if(max1 >= value1):
        max1 = value1
        index = 1
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value2):
        max1 = value2
        index = 2
        if (max1 == value2 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value3):
        max1 = value3
        index = 3
        if (max1 == value3 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value4):
        max1 = value4
        index = 4
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value5):
        max1 = value5
        index = 5
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value6):
        max1 = value6
        index = 6
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value7):
        max1 = value7
        index = 7
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value8):
        max1 = value8
        index = 8
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value9):
        max1 = value9
        index = 9
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value10):
        max1 = value10
        index = 0
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max == -1):
        print("No feasible region possible")
    else:
        if(multi > 1):
            print("Multiple minimum solutions")
        else:
            print("Unique minimum solution")
            
        if(index == 0):
            print("Minimum solution: x=0, y=0, value=0")
            
        if(index == 1):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex1_x,ex1_y,value1))
            
        if(index == 2):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex2_x,ex2_y,value2))
            
        if(index == 3):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex3_x,ex3_y,value3))
            
        if(index == 4):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex4_x,ex4_y,value4))
            
        if(index == 5):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex5_x,ex5_y,value5))
            
        if(index == 6):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex6_x,ex6_y,value6))
            
        if(index == 7):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex7_x,ex7_y,value7))
            
        if(index == 8):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex8_x,ex8_y,value8))
            
        if(index == 9):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex9_x,ex9_y,value9))
    
if ((d1 == 'leq') and (d2 == 'leq') and (d3 == 'geq')):
    #graph 
    # x >= 0
    x1 = (y*0) + 0
    # y >= 0
    y1 = (x*0) + 0
    # b1y <= a1x + c1 
    y2 = (c1 - (a1 * x))/b1
    # b2y <= a2x + c2 
    y3 = (c2 - (a2 * x))/b2
    # a3y >= b3x + c3 
    y4 = (c3 - (a3 * x))/b3
    plt.figure()
    plt.title('The graph of the LPP')
    plt.style.use('seaborn-whitegrid')
    plt.plot(x1, y, label=r'$x\geq0$')
    plt.plot(x, y1, label=r'$y\geq0$')
    plt.plot(x, y2, label= r'%dx + %dy $\leq$ %d' %(a1, b1, c1))
    plt.plot(x, y3, label= r'%dx + %dy $\leq$ %d' %(a2, b2, c2))
    plt.plot(x, y4, label= r'%dx + %dy $\geq$ %d' %(a3, b3, c3))
    plt.xlim((0, 100))
    plt.ylim((0, 100))
    plt.xlabel(r'$x$')
    plt.ylabel(r'$y$')
    #graph ends
    
    # Fill feasible region
    y5 = np.minimum(y2, y3)
    y6 = y4
    plt.fill_between(x, y5, y6, where=y5>y6, color='grey', alpha=0.3)
    plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
    
    #extreme point analysis
    
    if((((a1*(ex1_x)) + (b1*(ex1_y))) <= c1) and 
       (((a2*(ex1_x)) + (b2*(ex1_y))) <= c2) and 
       (((a3*(ex1_x)) + (b3*(ex1_y))) >= c3) and 
       (ex1_x >= 0) and (ex1_y >= 0)):
        value1 = (a*(ex1_x) + b*(ex1_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex1_x,ex1_y,value1))
        
    if((((a1*(ex2_x)) + (b1*(ex2_y))) <= c1) and 
       (((a2*(ex2_x)) + (b2*(ex2_y))) <= c2) and 
       (((a3*(ex2_x)) + (b3*(ex2_y))) >= c3) and 
       (ex2_x >= 0) and (ex2_y >= 0)):
        value2 = (a*(ex2_x) + b*(ex2_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex2_x,ex2_y,value2))
        
    if((((a1*(ex3_x)) + (b1*(ex3_y))) <= c1) and 
       (((a2*(ex3_x)) + (b2*(ex3_y))) <= c2) and 
       (((a3*(ex3_x)) + (b3*(ex3_y))) >= c3) and 
       (ex3_x >= 0) and (ex3_y >= 0)):
        value3 = (a*(ex3_x) + b*(ex3_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex3_x,ex3_y,value3))
        
    if((((a1*(ex4_x)) + (b1*(ex4_y))) <= c1) and 
       (((a2*(ex4_x)) + (b2*(ex4_y))) <= c2) and 
       (((a3*(ex4_x)) + (b3*(ex4_y))) >= c3) and 
       (ex4_x >= 0) and (ex4_y >= 0)):
        value4 = (a*(ex4_x) + b*(ex4_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex4_x,ex4_y,value4))
        
    if((((a1*(ex5_x)) + (b1*(ex5_y))) <= c1) and 
       (((a2*(ex5_x)) + (b2*(ex5_y))) <= c2) and 
       (((a3*(ex5_x)) + (b3*(ex5_y))) >= c3) and 
       (ex5_x >= 0) and (ex5_y >= 0)):
        value5 = (a*(ex5_x) + b*(ex5_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex5_x,ex5_y,value5))
        
    if((((a1*(ex6_x)) + (b1*(ex6_y))) <= c1) and 
       (((a2*(ex6_x)) + (b2*(ex6_y))) <= c2) and 
       (((a3*(ex6_x)) + (b3*(ex6_y))) >= c3) and 
       (ex6_x >= 0) and (ex6_y >= 0)):
        value6 = (a*(ex6_x) + b*(ex6_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex6_x,ex6_y,value6))
        
    if((((a1*(ex7_x)) + (b1*(ex7_y))) <= c1) and 
       (((a2*(ex7_x)) + (b2*(ex7_y))) <= c2) and 
       (((a3*(ex7_x)) + (b3*(ex7_y))) >= c3) and 
       (ex7_x >= 0) and (ex7_y >= 0)):
        value7 = (a*(ex7_x) + b*(ex7_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex7_x,ex7_y,value7))
        
    if((((a1*(ex8_x)) + (b1*(ex8_y))) <= c1) and 
       (((a2*(ex8_x)) + (b2*(ex8_y))) <= c2) and 
       (((a3*(ex8_x)) + (b3*(ex8_y))) >= c3) and 
       (ex8_x >= 0) and (ex8_y >= 0)):
        value8 = (a*(ex8_x) + b*(ex8_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex8_x,ex8_y,value8))
        
    if((((a1*(ex9_x)) + (b1*(ex9_y))) <= c1) and 
       (((a2*(ex9_x)) + (b2*(ex9_y))) <= c2) and 
       (((a3*(ex9_x)) + (b3*(ex9_y))) >= c3) and 
       (ex9_x >= 0) and (ex9_y >= 0)):
        value9 = (a*(ex9_x) + b*(ex9_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex9_x,ex9_y,value9))
        
    if(c1>=0 and c2>=0 and c3<=0):
        value10 = 0
        print("Extreme points: (0,0) Value: 0")
        
    if(max1 >= value1):
        max1 = value1
        index = 1
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value2):
        max1 = value2
        index = 2
        if (max1 == value2 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value3):
        max1 = value3
        index = 3
        if (max1 == value3 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value4):
        max1 = value4
        index = 4
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value5):
        max1 = value5
        index = 5
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value6):
        max1 = value6
        index = 6
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value7):
        max1 = value7
        index = 7
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value8):
        max1 = value8
        index = 8
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value9):
        max1 = value9
        index = 9
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value10):
        max1 = value10
        index = 0
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max == -1):
        print("No feasible region possible")
    else:
        if(multi > 1):
            print("Multiple minimum solutions")
        else:
            print("Unique minimum solution")
            
        if(index == 0):
            print("Minimum solution: x=0, y=0, value=0")
            
        if(index == 1):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex1_x,ex1_y,value1))
            
        if(index == 2):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex2_x,ex2_y,value2))
            
        if(index == 3):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex3_x,ex3_y,value3))
            
        if(index == 4):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex4_x,ex4_y,value4))
            
        if(index == 5):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex5_x,ex5_y,value5))
            
        if(index == 6):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex6_x,ex6_y,value6))
            
        if(index == 7):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex7_x,ex7_y,value7))
            
        if(index == 8):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex8_x,ex8_y,value8))
            
        if(index == 9):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex9_x,ex9_y,value9))
    
if ((d1 == 'leq') and (d2 == 'geq') and (d3 == 'leq')):
    #graph
    # x >= 0
    x1 = (y*0) + 0
    # y >= 0
    y1 = (x*0) + 0
    # b1y <= a1x + c1 
    y2 = (c1 - (a1 * x))/b1
    # b2y >= a2x + c2 
    y3 = (c2 - (a2 * x))/b2
    # a3y <= b3x + c3 
    y4 = (c3 - (a3 * x))/b3
    plt.figure()
    plt.title('The graph of the LPP')
    plt.style.use('seaborn-whitegrid')
    plt.plot(x1, y, label=r'$x\geq0$')
    plt.plot(x, y1, label=r'$y\geq0$')
    plt.plot(x, y2, label= r'%dx + %dy $\leq$ %d' %(a1, b1, c1))
    plt.plot(x, y3, label= r'%dx + %dy $\geq$ %d' %(a2, b2, c2))
    plt.plot(x, y4, label= r'%dx + %dy $\leq$ %d' %(a3, b3, c3))
    plt.xlim((0, 100))
    plt.ylim((0, 100))
    plt.xlabel(r'$x$')
    plt.ylabel(r'$y$')
    #graph ends
    
    # Fill feasible region
    y5 = np.minimum(y2, y4)
    y6 = y3
    plt.fill_between(x, y5, y6, where=y5>y6, color='grey', alpha=0.3)
    plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
    
   #extreme point analysis
    
    if((((a1*(ex1_x)) + (b1*(ex1_y))) <= c1) and 
       (((a2*(ex1_x)) + (b2*(ex1_y))) >= c2) and 
       (((a3*(ex1_x)) + (b3*(ex1_y))) <= c3) and 
       (ex1_x >= 0) and (ex1_y >= 0)):
        value1 = (a*(ex1_x) + b*(ex1_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex1_x,ex1_y,value1))
        
    if((((a1*(ex2_x)) + (b1*(ex2_y))) <= c1) and 
       (((a2*(ex2_x)) + (b2*(ex2_y))) >= c2) and 
       (((a3*(ex2_x)) + (b3*(ex2_y))) <= c3) and 
       (ex2_x >= 0) and (ex2_y >= 0)):
        value2 = (a*(ex2_x) + b*(ex2_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex2_x,ex2_y,value2))
        
    if((((a1*(ex3_x)) + (b1*(ex3_y))) <= c1) and 
       (((a2*(ex3_x)) + (b2*(ex3_y))) >= c2) and 
       (((a3*(ex3_x)) + (b3*(ex3_y))) <= c3) and 
       (ex3_x >= 0) and (ex3_y >= 0)):
        value3 = (a*(ex3_x) + b*(ex3_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex3_x,ex3_y,value3))
        
    if((((a1*(ex4_x)) + (b1*(ex4_y))) <= c1) and 
       (((a2*(ex4_x)) + (b2*(ex4_y))) >= c2) and 
       (((a3*(ex4_x)) + (b3*(ex4_y))) <= c3) and 
       (ex4_x >= 0) and (ex4_y >= 0)):
        value4 = (a*(ex4_x) + b*(ex4_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex4_x,ex4_y,value4))
        
    if((((a1*(ex5_x)) + (b1*(ex5_y))) <= c1) and 
       (((a2*(ex5_x)) + (b2*(ex5_y))) >= c2) and 
       (((a3*(ex5_x)) + (b3*(ex5_y))) <= c3) and 
       (ex5_x >= 0) and (ex5_y >= 0)):
        value5 = (a*(ex5_x) + b*(ex5_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex5_x,ex5_y,value5))
        
    if((((a1*(ex6_x)) + (b1*(ex6_y))) <= c1) and 
       (((a2*(ex6_x)) + (b2*(ex6_y))) >= c2) and 
       (((a3*(ex6_x)) + (b3*(ex6_y))) <= c3) and 
       (ex6_x >= 0) and (ex6_y >= 0)):
        value6 = (a*(ex6_x) + b*(ex6_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex6_x,ex6_y,value6))
        
    if((((a1*(ex7_x)) + (b1*(ex7_y))) <= c1) and 
       (((a2*(ex7_x)) + (b2*(ex7_y))) >= c2) and 
       (((a3*(ex7_x)) + (b3*(ex7_y))) <= c3) and 
       (ex7_x >= 0) and (ex7_y >= 0)):
        value7 = (a*(ex7_x) + b*(ex7_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex7_x,ex7_y,value7))
        
    if((((a1*(ex8_x)) + (b1*(ex8_y))) <= c1) and 
       (((a2*(ex8_x)) + (b2*(ex8_y))) >= c2) and 
       (((a3*(ex8_x)) + (b3*(ex8_y))) <= c3) and 
       (ex8_x >= 0) and (ex8_y >= 0)):
        value8 = (a*(ex8_x) + b*(ex8_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex8_x,ex8_y,value8))
        
    if((((a1*(ex9_x)) + (b1*(ex9_y))) <= c1) and 
       (((a2*(ex9_x)) + (b2*(ex9_y))) >= c2) and 
       (((a3*(ex9_x)) + (b3*(ex9_y))) <= c3) and 
       (ex9_x >= 0) and (ex9_y >= 0)):
        value9 = (a*(ex9_x) + b*(ex9_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex9_x,ex9_y,value9))
        
    if(c1>=0 and c2<=0 and c3>=0):
        value10 = 0
        print("Extreme points: (0,0) Value: 0")
        
    if(max1 >= value1):
        max1 = value1
        index = 1
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value2):
        max1 = value2
        index = 2
        if (max1 == value2 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value3):
        max1 = value3
        index = 3
        if (max1 == value3 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value4):
        max1 = value4
        index = 4
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value5):
        max1 = value5
        index = 5
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value6):
        max1 = value6
        index = 6
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value7):
        max1 = value7
        index = 7
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value8):
        max1 = value8
        index = 8
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value9):
        max1 = value9
        index = 9
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value10):
        max1 = value10
        index = 0
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max == -1):
        print("No feasible region possible")
    else:
        if(multi > 1):
            print("Multiple minimum solutions")
        else:
            print("Unique minimum solution")
            
        if(index == 0):
            print("Minimum solution: x=0, y=0, value=0")
            
        if(index == 1):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex1_x,ex1_y,value1))
            
        if(index == 2):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex2_x,ex2_y,value2))
            
        if(index == 3):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex3_x,ex3_y,value3))
            
        if(index == 4):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex4_x,ex4_y,value4))
            
        if(index == 5):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex5_x,ex5_y,value5))
            
        if(index == 6):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex6_x,ex6_y,value6))
            
        if(index == 7):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex7_x,ex7_y,value7))
            
        if(index == 8):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex8_x,ex8_y,value8))
            
        if(index == 9):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex9_x,ex9_y,value9))
    
if ((d1 == 'leq') and (d2 == 'geq') and (d3 == 'geq')):
    #graph
    # x >= 0
    x1 = (y*0) + 0
    # y >= 0
    y1 = (x*0) + 0
    # b1y <= a1x + c1 
    y2 = (c1 - (a1 * x))/b1
    # b2y >= a2x + c2 
    y3 = (c2 - (a2 * x))/b2
    # a3y >= b3x + c3 
    y4 = (c3 - (a3 * x))/b3
    plt.figure()
    plt.title('The graph of the LPP')
    plt.style.use('seaborn-whitegrid')
    plt.plot(x1, y, label=r'$x\geq0$')
    plt.plot(x, y1, label=r'$y\geq0$')
    plt.plot(x, y2, label= r'%dx + %dy $\leq$ %d' %(a1, b1, c1))
    plt.plot(x, y3, label= r'%dx + %dy $\geq$ %d' %(a2, b2, c2))
    plt.plot(x, y4, label= r'%dx + %dy $\geq$ %d' %(a3, b3, c3))
    plt.xlim((0, 100))
    plt.ylim((0, 100))
    plt.xlabel(r'$x$')
    plt.ylabel(r'$y$')
    #graph ends
    
    # Fill feasible region
    y5 = y2
    y6 = np.maximum(y4, y3)
    plt.fill_between(x, y5, y6, where=y5>y6, color='grey', alpha=0.3)
    plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
    
    #extreme point analysis
    
    if((((a1*(ex1_x)) + (b1*(ex1_y))) <= c1) and 
       (((a2*(ex1_x)) + (b2*(ex1_y))) >= c2) and 
       (((a3*(ex1_x)) + (b3*(ex1_y))) >= c3) and 
       (ex1_x >= 0) and (ex1_y >= 0)):
        value1 = (a*(ex1_x) + b*(ex1_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex1_x,ex1_y,value1))
        
    if((((a1*(ex2_x)) + (b1*(ex2_y))) <= c1) and 
       (((a2*(ex2_x)) + (b2*(ex2_y))) >= c2) and 
       (((a3*(ex2_x)) + (b3*(ex2_y))) >= c3) and 
       (ex2_x >= 0) and (ex2_y >= 0)):
        value2 = (a*(ex2_x) + b*(ex2_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex2_x,ex2_y,value2))
        
    if((((a1*(ex3_x)) + (b1*(ex3_y))) <= c1) and 
       (((a2*(ex3_x)) + (b2*(ex3_y))) >= c2) and 
       (((a3*(ex3_x)) + (b3*(ex3_y))) >= c3) and 
       (ex3_x >= 0) and (ex3_y >= 0)):
        value3 = (a*(ex3_x) + b*(ex3_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex3_x,ex3_y,value3))
        
    if((((a1*(ex4_x)) + (b1*(ex4_y))) <= c1) and 
       (((a2*(ex4_x)) + (b2*(ex4_y))) >= c2) and 
       (((a3*(ex4_x)) + (b3*(ex4_y))) >= c3) and 
       (ex4_x >= 0) and (ex4_y >= 0)):
        value4 = (a*(ex4_x) + b*(ex4_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex4_x,ex4_y,value4))
        
    if((((a1*(ex5_x)) + (b1*(ex5_y))) <= c1) and 
       (((a2*(ex5_x)) + (b2*(ex5_y))) >= c2) and 
       (((a3*(ex5_x)) + (b3*(ex5_y))) >= c3) and 
       (ex5_x >= 0) and (ex5_y >= 0)):
        value5 = (a*(ex5_x) + b*(ex5_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex5_x,ex5_y,value5))
        
    if((((a1*(ex6_x)) + (b1*(ex6_y))) <= c1) and 
       (((a2*(ex6_x)) + (b2*(ex6_y))) >= c2) and 
       (((a3*(ex6_x)) + (b3*(ex6_y))) >= c3) and 
       (ex6_x >= 0) and (ex6_y >= 0)):
        value6 = (a*(ex6_x) + b*(ex6_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex6_x,ex6_y,value6))
        
    if((((a1*(ex7_x)) + (b1*(ex7_y))) <= c1) and 
       (((a2*(ex7_x)) + (b2*(ex7_y))) >= c2) and 
       (((a3*(ex7_x)) + (b3*(ex7_y))) >= c3) and 
       (ex7_x >= 0) and (ex7_y >= 0)):
        value7 = (a*(ex7_x) + b*(ex7_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex7_x,ex7_y,value7))
        
    if((((a1*(ex8_x)) + (b1*(ex8_y))) <= c1) and 
       (((a2*(ex8_x)) + (b2*(ex8_y))) >= c2) and 
       (((a3*(ex8_x)) + (b3*(ex8_y))) >= c3) and 
       (ex8_x >= 0) and (ex8_y >= 0)):
        value8 = (a*(ex8_x) + b*(ex8_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex8_x,ex8_y,value8))
        
    if((((a1*(ex9_x)) + (b1*(ex9_y))) <= c1) and 
       (((a2*(ex9_x)) + (b2*(ex9_y))) >= c2) and 
       (((a3*(ex9_x)) + (b3*(ex9_y))) >= c3) and 
       (ex9_x >= 0) and (ex9_y >= 0)):
        value9 = (a*(ex9_x) + b*(ex9_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex9_x,ex9_y,value9))
        
    if(c1>=0 and c2<=0 and c3<=0):
        value10 = 0
        print("Extreme points: (0,0) Value: 0")
        
    if(max1 >= value1):
        max1 = value1
        index = 1
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value2):
        max1 = value2
        index = 2
        if (max1 == value2 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value3):
        max1 = value3
        index = 3
        if (max1 == value3 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value4):
        max1 = value4
        index = 4
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value5):
        max1 = value5
        index = 5
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value6):
        max1 = value6
        index = 6
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value7):
        max1 = value7
        index = 7
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value8):
        max1 = value8
        index = 8
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value9):
        max1 = value9
        index = 9
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value10):
        max1 = value10
        index = 0
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max == -1):
        print("No feasible region possible")
    else:
        if(multi > 1):
            print("Multiple minimum solutions")
        else:
            print("Unique minimum solution")
            
        if(index == 0):
            print("Minimum solution: x=0, y=0, value=0")
            
        if(index == 1):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex1_x,ex1_y,value1))
            
        if(index == 2):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex2_x,ex2_y,value2))
            
        if(index == 3):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex3_x,ex3_y,value3))
            
        if(index == 4):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex4_x,ex4_y,value4))
            
        if(index == 5):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex5_x,ex5_y,value5))
            
        if(index == 6):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex6_x,ex6_y,value6))
            
        if(index == 7):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex7_x,ex7_y,value7))
            
        if(index == 8):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex8_x,ex8_y,value8))
            
        if(index == 9):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex9_x,ex9_y,value9))
    
if ((d1 == 'geq') and (d2 == 'leq') and (d3 == 'leq')):
    #graph
    # x >= 0
    x1 = (y*0) + 0
    # y >= 0
    y1 = (x*0) + 0
    # b1y >= a1x + c1 
    y2 = (c1 - (a1 * x))/b1
    # b2y <= a2x + c2 
    y3 = (c2 - (a2 * x))/b2
    # a3y <= b3x + c3 
    y4 = (c3 - (a3 * x))/b3
    plt.figure()
    plt.title('The graph of the LPP')
    plt.style.use('seaborn-whitegrid')
    plt.plot(x1, y, label=r'$x\geq0$')
    plt.plot(x, y1, label=r'$y\geq0$')
    plt.plot(x, y2, label= r'%dx + %dy $\geq$ %d' %(a1, b1, c1))
    plt.plot(x, y3, label= r'%dx + %dy $\leq$ %d' %(a2, b2, c2))
    plt.plot(x, y4, label= r'%dx + %dy $\leq$ %d' %(a3, b3, c3))
    plt.xlim((0, 100))
    plt.ylim((0, 100))
    plt.xlabel(r'$x$')
    plt.ylabel(r'$y$')
    #graph ends
    
    # Fill feasible region
    y5 = np.minimum(y3, y4)
    y6 = y2
    plt.fill_between(x, y5, y6, where=y5>y6, color='grey', alpha=0.3)
    plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
    
    #extreme point analysis
    
    if((((a1*(ex1_x)) + (b1*(ex1_y))) >= c1) and 
       (((a2*(ex1_x)) + (b2*(ex1_y))) <= c2) and 
       (((a3*(ex1_x)) + (b3*(ex1_y))) <= c3) and 
       (ex1_x >= 0) and (ex1_y >= 0)):
        value1 = (a*(ex1_x) + b*(ex1_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex1_x,ex1_y,value1))
        
    if((((a1*(ex2_x)) + (b1*(ex2_y))) >= c1) and 
       (((a2*(ex2_x)) + (b2*(ex2_y))) <= c2) and 
       (((a3*(ex2_x)) + (b3*(ex2_y))) <= c3) and 
       (ex2_x >= 0) and (ex2_y >= 0)):
        value2 = (a*(ex2_x) + b*(ex2_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex2_x,ex2_y,value2))
        
    if((((a1*(ex3_x)) + (b1*(ex3_y))) >= c1) and 
       (((a2*(ex3_x)) + (b2*(ex3_y))) <= c2) and 
       (((a3*(ex3_x)) + (b3*(ex3_y))) <= c3) and 
       (ex3_x >= 0) and (ex3_y >= 0)):
        value3 = (a*(ex3_x) + b*(ex3_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex3_x,ex3_y,value3))
        
    if((((a1*(ex4_x)) + (b1*(ex4_y))) >= c1) and 
       (((a2*(ex4_x)) + (b2*(ex4_y))) <= c2) and 
       (((a3*(ex4_x)) + (b3*(ex4_y))) <= c3) and 
       (ex4_x >= 0) and (ex4_y >= 0)):
        value4 = (a*(ex4_x) + b*(ex4_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex4_x,ex4_y,value4))
        
    if((((a1*(ex5_x)) + (b1*(ex5_y))) >= c1) and 
       (((a2*(ex5_x)) + (b2*(ex5_y))) <= c2) and 
       (((a3*(ex5_x)) + (b3*(ex5_y))) <= c3) and 
       (ex5_x >= 0) and (ex5_y >= 0)):
        value5 = (a*(ex5_x) + b*(ex5_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex5_x,ex5_y,value5))
        
    if((((a1*(ex6_x)) + (b1*(ex6_y))) >= c1) and 
       (((a2*(ex6_x)) + (b2*(ex6_y))) <= c2) and 
       (((a3*(ex6_x)) + (b3*(ex6_y))) <= c3) and 
       (ex6_x >= 0) and (ex6_y >= 0)):
        value6 = (a*(ex6_x) + b*(ex6_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex6_x,ex6_y,value6))
        
    if((((a1*(ex7_x)) + (b1*(ex7_y))) >= c1) and 
       (((a2*(ex7_x)) + (b2*(ex7_y))) <= c2) and 
       (((a3*(ex7_x)) + (b3*(ex7_y))) <= c3) and 
       (ex7_x >= 0) and (ex7_y >= 0)):
        value7 = (a*(ex7_x) + b*(ex7_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex7_x,ex7_y,value7))
        
    if((((a1*(ex8_x)) + (b1*(ex8_y))) >= c1) and 
       (((a2*(ex8_x)) + (b2*(ex8_y))) <= c2) and 
       (((a3*(ex8_x)) + (b3*(ex8_y))) <= c3) and 
       (ex8_x >= 0) and (ex8_y >= 0)):
        value8 = (a*(ex8_x) + b*(ex8_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex8_x,ex8_y,value8))
        
    if((((a1*(ex9_x)) + (b1*(ex9_y))) >= c1) and 
       (((a2*(ex9_x)) + (b2*(ex9_y))) <= c2) and 
       (((a3*(ex9_x)) + (b3*(ex9_y))) <= c3) and 
       (ex9_x >= 0) and (ex9_y >= 0)):
        value9 = (a*(ex9_x) + b*(ex9_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex9_x,ex9_y,value9))
        
    if(c1<=0 and c2>=0 and c3>=0):
        value10 = 0
        print("Extreme points: (0,0) Value: 0")
        
    if(max1 >= value1):
        max1 = value1
        index = 1
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value2):
        max1 = value2
        index = 2
        if (max1 == value2 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value3):
        max1 = value3
        index = 3
        if (max1 == value3 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value4):
        max1 = value4
        index = 4
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value5):
        max1 = value5
        index = 5
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value6):
        max1 = value6
        index = 6
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value7):
        max1 = value7
        index = 7
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value8):
        max1 = value8
        index = 8
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value9):
        max1 = value9
        index = 9
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value10):
        max1 = value10
        index = 0
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max == -1):
        print("No feasible region possible")
    else:
        if(multi > 1):
            print("Multiple minimum solutions")
        else:
            print("Unique minimum solution")
            
        if(index == 0):
            print("Minimum solution: x=0, y=0, value=0")
            
        if(index == 1):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex1_x,ex1_y,value1))
            
        if(index == 2):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex2_x,ex2_y,value2))
            
        if(index == 3):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex3_x,ex3_y,value3))
            
        if(index == 4):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex4_x,ex4_y,value4))
            
        if(index == 5):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex5_x,ex5_y,value5))
            
        if(index == 6):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex6_x,ex6_y,value6))
            
        if(index == 7):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex7_x,ex7_y,value7))
            
        if(index == 8):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex8_x,ex8_y,value8))
            
        if(index == 9):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex9_x,ex9_y,value9))
    
if ((d1 == 'geq') and (d2 == 'leq') and (d3 == 'geq')):
    #graph
    # x >= 0
    x1 = (y*0) + 0
    # y >= 0
    y1 = (x*0) + 0
    # b1y >= a1x + c1 
    y2 = (c1 - (a1 * x))/b1
    # b2y <= a2x + c2 
    y3 = (c2 - (a2 * x))/b2
    # a3y >= b3x + c3 
    y4 = (c3 - (a3 * x))/b3
    plt.figure()
    plt.title('The graph of the LPP')
    plt.style.use('seaborn-whitegrid')
    plt.plot(x1, y, label=r'$x\geq0$')
    plt.plot(x, y1, label=r'$y\geq0$')
    plt.plot(x, y2, label= r'%dx + %dy $\geq$ %d' %(a1, b1, c1))
    plt.plot(x, y3, label= r'%dx + %dy $\leq$ %d' %(a2, b2, c2))
    plt.plot(x, y4, label= r'%dx + %dy $\geq$ %d' %(a3, b3, c3))
    plt.xlim((0, 100))
    plt.ylim((0, 100))
    plt.xlabel(r'$x$')
    plt.ylabel(r'$y$')
    #graph ends
    
    # Fill feasible region
    y5 = y3
    y6 = np.maximum(y2, y4)
    plt.fill_between(x, y5, y6, where=y5>y6, color='grey', alpha=0.3)
    plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
    
    #extreme point analysis
    
    if((((a1*(ex1_x)) + (b1*(ex1_y))) >= c1) and 
       (((a2*(ex1_x)) + (b2*(ex1_y))) <= c2) and 
       (((a3*(ex1_x)) + (b3*(ex1_y))) >= c3) and 
       (ex1_x >= 0) and (ex1_y >= 0)):
        value1 = (a*(ex1_x) + b*(ex1_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex1_x,ex1_y,value1))
        
    if((((a1*(ex2_x)) + (b1*(ex2_y))) >= c1) and 
       (((a2*(ex2_x)) + (b2*(ex2_y))) <= c2) and 
       (((a3*(ex2_x)) + (b3*(ex2_y))) >= c3) and 
       (ex2_x >= 0) and (ex2_y >= 0)):
        value2 = (a*(ex2_x) + b*(ex2_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex2_x,ex2_y,value2))
        
    if((((a1*(ex3_x)) + (b1*(ex3_y))) >= c1) and 
       (((a2*(ex3_x)) + (b2*(ex3_y))) <= c2) and 
       (((a3*(ex3_x)) + (b3*(ex3_y))) >= c3) and 
       (ex3_x >= 0) and (ex3_y >= 0)):
        value3 = (a*(ex3_x) + b*(ex3_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex3_x,ex3_y,value3))
        
    if((((a1*(ex4_x)) + (b1*(ex4_y))) >= c1) and 
       (((a2*(ex4_x)) + (b2*(ex4_y))) <= c2) and 
       (((a3*(ex4_x)) + (b3*(ex4_y))) >= c3) and 
       (ex4_x >= 0) and (ex4_y >= 0)):
        value4 = (a*(ex4_x) + b*(ex4_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex4_x,ex4_y,value4))
        
    if((((a1*(ex5_x)) + (b1*(ex5_y))) >= c1) and 
       (((a2*(ex5_x)) + (b2*(ex5_y))) <= c2) and 
       (((a3*(ex5_x)) + (b3*(ex5_y))) >= c3) and 
       (ex5_x >= 0) and (ex5_y >= 0)):
        value5 = (a*(ex5_x) + b*(ex5_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex5_x,ex5_y,value5))
        
    if((((a1*(ex6_x)) + (b1*(ex6_y))) >= c1) and 
       (((a2*(ex6_x)) + (b2*(ex6_y))) <= c2) and 
       (((a3*(ex6_x)) + (b3*(ex6_y))) >= c3) and 
       (ex6_x >= 0) and (ex6_y >= 0)):
        value6 = (a*(ex6_x) + b*(ex6_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex6_x,ex6_y,value6))
        
    if((((a1*(ex7_x)) + (b1*(ex7_y))) >= c1) and 
       (((a2*(ex7_x)) + (b2*(ex7_y))) <= c2) and 
       (((a3*(ex7_x)) + (b3*(ex7_y))) >= c3) and 
       (ex7_x >= 0) and (ex7_y >= 0)):
        value7 = (a*(ex7_x) + b*(ex7_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex7_x,ex7_y,value7))
        
    if((((a1*(ex8_x)) + (b1*(ex8_y))) >= c1) and 
       (((a2*(ex8_x)) + (b2*(ex8_y))) <= c2) and 
       (((a3*(ex8_x)) + (b3*(ex8_y))) >= c3) and 
       (ex8_x >= 0) and (ex8_y >= 0)):
        value8 = (a*(ex8_x) + b*(ex8_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex8_x,ex8_y,value8))
        
    if((((a1*(ex9_x)) + (b1*(ex9_y))) >= c1) and 
       (((a2*(ex9_x)) + (b2*(ex9_y))) <= c2) and 
       (((a3*(ex9_x)) + (b3*(ex9_y))) >= c3) and 
       (ex9_x >= 0) and (ex9_y >= 0)):
        value9 = (a*(ex9_x) + b*(ex9_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex9_x,ex9_y,value9))
        
    if(c1<=0 and c2>=0 and c3<=0):
        value10 = 0
        print("Extreme points: (0,0) Value: 0")
        
    if(max1 >= value1):
        max1 = value1
        index = 1
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value2):
        max1 = value2
        index = 2
        if (max1 == value2 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value3):
        max1 = value3
        index = 3
        if (max1 == value3 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value4):
        max1 = value4
        index = 4
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value5):
        max1 = value5
        index = 5
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value6):
        max1 = value6
        index = 6
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value7):
        max1 = value7
        index = 7
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value8):
        max1 = value8
        index = 8
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value9):
        max1 = value9
        index = 9
        if (max1 == value1 and multi > 0):
            multi = multi + 1 
        else:
            multi = 1
        
    if(max1 >= value10):
        max1 = value10
        index = 0
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max == -1):
        print("No feasible region possible")
    else:
        if(multi > 1):
            print("Multiple minimum solutions")
        else:
            print("Unique minimum solution")
            
        if(index == 0):
            print("Minimum solution: x=0, y=0, value=0")
            
        if(index == 1):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex1_x,ex1_y,value1))
            
        if(index == 2):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex2_x,ex2_y,value2))
            
        if(index == 3):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex3_x,ex3_y,value3))
            
        if(index == 4):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex4_x,ex4_y,value4))
            
        if(index == 5):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex5_x,ex5_y,value5))
            
        if(index == 6):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex6_x,ex6_y,value6))
            
        if(index == 7):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex7_x,ex7_y,value7))
            
        if(index == 8):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex8_x,ex8_y,value8))
            
        if(index == 9):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex9_x,ex9_y,value9))
    
if ((d1 == 'geq') and (d2 == 'geq') and (d3 == 'leq')):
    #graph
    # x >= 0
    x1 = (y*0) + 0
    # y >= 0
    y1 = (x*0) + 0
    # b1y >= a1x + c1 
    y2 = (c1 - (a1 * x))/b1
    # b2y >= a2x + c2 
    y3 = (c2 - (a2 * x))/b2
    # a3y <= b3x + c3 
    y4 = (c3 - (a3 * x))/b3
    plt.figure()
    plt.title('The graph of the LPP')
    plt.style.use('seaborn-whitegrid')
    plt.plot(x1, y, label=r'$x\geq0$')
    plt.plot(x, y1, label=r'$y\geq0$')
    plt.plot(x, y2, label= r'%dx + %dy $\geq$ %d' %(a1, b1, c1))
    plt.plot(x, y3, label= r'%dx + %dy $\geq$ %d' %(a2, b2, c2))
    plt.plot(x, y4, label= r'%dx + %dy $\leq$ %d' %(a3, b3, c3))
    plt.xlim((0, 100))
    plt.ylim((0, 100))
    plt.xlabel(r'$x$')
    plt.ylabel(r'$y$')
    #graph ends
    # Fill feasible region
    y5 = y4
    y6 = np.maximum(y2, y3)
    plt.fill_between(x, y5, y6, where=y5>y6, color='grey', alpha=0.3)
    plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)
    
    #extreme point analysis
    
    if((((a1*(ex1_x)) + (b1*(ex1_y))) >= c1) and 
       (((a2*(ex1_x)) + (b2*(ex1_y))) >= c2) and 
       (((a3*(ex1_x)) + (b3*(ex1_y))) <= c3) and 
       (ex1_x >= 0) and (ex1_y >= 0)):
        value1 = (a*(ex1_x) + b*(ex1_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex1_x,ex1_y,value1))
        
    if((((a1*(ex2_x)) + (b1*(ex2_y))) >= c1) and 
       (((a2*(ex2_x)) + (b2*(ex2_y))) >= c2) and 
       (((a3*(ex2_x)) + (b3*(ex2_y))) <= c3) and 
       (ex2_x >= 0) and (ex2_y >= 0)):
        value2 = (a*(ex2_x) + b*(ex2_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex2_x,ex2_y,value2))
        
    if((((a1*(ex3_x)) + (b1*(ex3_y))) >= c1) and 
       (((a2*(ex3_x)) + (b2*(ex3_y))) >= c2) and 
       (((a3*(ex3_x)) + (b3*(ex3_y))) <= c3) and 
       (ex3_x >= 0) and (ex3_y >= 0)):
        value3 = (a*(ex3_x) + b*(ex3_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex3_x,ex3_y,value3))
        
    if((((a1*(ex4_x)) + (b1*(ex4_y))) >= c1) and 
       (((a2*(ex4_x)) + (b2*(ex4_y))) >= c2) and 
       (((a3*(ex4_x)) + (b3*(ex4_y))) <= c3) and 
       (ex4_x >= 0) and (ex4_y >= 0)):
        value4 = (a*(ex4_x) + b*(ex4_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex4_x,ex4_y,value4))
        
    if((((a1*(ex5_x)) + (b1*(ex5_y))) >= c1) and 
       (((a2*(ex5_x)) + (b2*(ex5_y))) >= c2) and 
       (((a3*(ex5_x)) + (b3*(ex5_y))) <= c3) and 
       (ex5_x >= 0) and (ex5_y >= 0)):
        value5 = (a*(ex5_x) + b*(ex5_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex5_x,ex5_y,value5))
        
    if((((a1*(ex6_x)) + (b1*(ex6_y))) >= c1) and 
       (((a2*(ex6_x)) + (b2*(ex6_y))) >= c2) and 
       (((a3*(ex6_x)) + (b3*(ex6_y))) <= c3) and 
       (ex6_x >= 0) and (ex6_y >= 0)):
        value6 = (a*(ex6_x) + b*(ex6_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex6_x,ex6_y,value6))
        
    if((((a1*(ex7_x)) + (b1*(ex7_y))) >= c1) and 
       (((a2*(ex7_x)) + (b2*(ex7_y))) >= c2) and 
       (((a3*(ex7_x)) + (b3*(ex7_y))) <= c3) and 
       (ex7_x >= 0) and (ex7_y >= 0)):
        value7 = (a*(ex7_x) + b*(ex7_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex7_x,ex7_y,value7))
        
    if((((a1*(ex8_x)) + (b1*(ex8_y))) >= c1) and 
       (((a2*(ex8_x)) + (b2*(ex8_y))) >= c2) and 
       (((a3*(ex8_x)) + (b3*(ex8_y))) <= c3) and 
       (ex8_x >= 0) and (ex8_y >= 0)):
        value8 = (a*(ex8_x) + b*(ex8_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex8_x,ex8_y,value8))
        
    if((((a1*(ex9_x)) + (b1*(ex9_y))) >= c1) and 
       (((a2*(ex9_x)) + (b2*(ex9_y))) >= c2) and 
       (((a3*(ex9_x)) + (b3*(ex9_y))) <= c3) and 
       (ex9_x >= 0) and (ex9_y >= 0)):
        value9 = (a*(ex9_x) + b*(ex9_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex9_x,ex9_y,value9))
        
    if(c1<=0 and c2<=0 and c3>=0):
        value10 = 0
        print("Extreme points: (0,0) Value: 0")
        
    if(max1 >= value1):
        max1 = value1
        index = 1
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value2):
        max1 = value2
        index = 2
        if (max1 == value2 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value3):
        max1 = value3
        index = 3
        if (max1 == value3 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value4):
        max1 = value4
        index = 4
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value5):
        max1 = value5
        index = 5
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value6):
        max1 = value6
        index = 6
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value7):
        max1 = value7
        index = 7
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value8):
        max1 = value8
        index = 8
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value9):
        max1 = value9
        index = 9
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value10):
        max1 = value10
        index = 0
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max == -1):
        print("No feasible region possible")
    else:
        if(multi > 1):
            print("Multiple minimum solutions")
        else:
            print("Unique minimum solution")
            
        if(index == 0):
            print("Minimum solution: x=0, y=0, value=0")
            
        if(index == 1):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex1_x,ex1_y,value1))
            
        if(index == 2):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex2_x,ex2_y,value2))
            
        if(index == 3):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex3_x,ex3_y,value3))
            
        if(index == 4):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex4_x,ex4_y,value4))
            
        if(index == 5):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex5_x,ex5_y,value5))
            
        if(index == 6):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex6_x,ex6_y,value6))
            
        if(index == 7):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex7_x,ex7_y,value7))
            
        if(index == 8):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex8_x,ex8_y,value8))
            
        if(index == 9):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex9_x,ex9_y,value9))
    
if ((d1 == 'geq') and (d2 == 'geq') and (d3 == 'geq')):
    #graph
    # x >= 0
    x1 = (y*0) + 0
    # y >= 0
    y1 = (x*0) + 0
    # b1y >= a1x + c1 
    y2 = (c1 - (a1 * x))/b1
    # b2y >= a2x + c2 
    y3 = (c2 - (a2 * x))/b2
    # a3y >= b3x + c3 
    y4 = (c3 - (a3 * x))/b3
    plt.figure()
    plt.title('The graph of the LPP')
    plt.style.use('seaborn-whitegrid')
    plt.plot(x1, y, label=r'$x\geq0$')
    plt.plot(x, y1, label=r'$y\geq0$')
    plt.plot(x, y2, label= r'%dx + %dy $\geq$ %d' %(a1, b1, c1))
    plt.plot(x, y3, label= r'%dx + %dy $\geq$ %d' %(a2, b2, c2))
    plt.plot(x, y4, label= r'%dx + %dy $\geq$ %d' %(a3, b3, c3))
    plt.xlim((0, 100))
    plt.ylim((0, 100))
    plt.xlabel(r'$x$')
    plt.ylabel(r'$y$')
    #graph ends
    
    # Fill feasible region
    y5 = 0
    y6 = np.maximum(y2, y3)
    y6 = np.maximum(y4, y6)
    plt.fill_between(x, y5, y6, where=y5>y6, color='grey', alpha=0.3)
    plt.legend(bbox_to_anchor=(1.05, 1), loc=2, borderaxespad=0.)

    #extreme point analysis
    
    if((((a1*(ex1_x)) + (b1*(ex1_y))) >= c1) and 
       (((a2*(ex1_x)) + (b2*(ex1_y))) >= c2) and 
       (((a3*(ex1_x)) + (b3*(ex1_y))) >= c3) and 
       (ex1_x >= 0) and (ex1_y >= 0)):
        value1 = (a*(ex1_x) + b*(ex1_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex1_x,ex1_y,value1))
        
    if((((a1*(ex2_x)) + (b1*(ex2_y))) >= c1) and 
       (((a2*(ex2_x)) + (b2*(ex2_y))) >= c2) and 
       (((a3*(ex2_x)) + (b3*(ex2_y))) >= c3) and 
       (ex2_x >= 0) and (ex2_y >= 0)):
        value2 = (a*(ex2_x) + b*(ex2_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex2_x,ex2_y,value2))
        
    if((((a1*(ex3_x)) + (b1*(ex3_y))) >= c1) and 
       (((a2*(ex3_x)) + (b2*(ex3_y))) >= c2) and 
       (((a3*(ex3_x)) + (b3*(ex3_y))) >= c3) and 
       (ex3_x >= 0) and (ex3_y >= 0)):
        value3 = (a*(ex3_x) + b*(ex3_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex3_x,ex3_y,value3))
        
    if((((a1*(ex4_x)) + (b1*(ex4_y))) >= c1) and 
       (((a2*(ex4_x)) + (b2*(ex4_y))) >= c2) and 
       (((a3*(ex4_x)) + (b3*(ex4_y))) >= c3) and 
       (ex4_x >= 0) and (ex4_y >= 0)):
        value4 = (a*(ex4_x) + b*(ex4_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex4_x,ex4_y,value4))
        
    if((((a1*(ex5_x)) + (b1*(ex5_y))) >= c1) and 
       (((a2*(ex5_x)) + (b2*(ex5_y))) >= c2) and 
       (((a3*(ex5_x)) + (b3*(ex5_y))) >= c3) and 
       (ex5_x >= 0) and (ex5_y >= 0)):
        value5 = (a*(ex5_x) + b*(ex5_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex5_x,ex5_y,value5))
        
    if((((a1*(ex6_x)) + (b1*(ex6_y))) >= c1) and 
       (((a2*(ex6_x)) + (b2*(ex6_y))) >= c2) and 
       (((a3*(ex6_x)) + (b3*(ex6_y))) >= c3) and 
       (ex6_x >= 0) and (ex6_y >= 0)):
        value6 = (a*(ex6_x) + b*(ex6_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex6_x,ex6_y,value6))
        
    if((((a1*(ex7_x)) + (b1*(ex7_y))) >= c1) and 
       (((a2*(ex7_x)) + (b2*(ex7_y))) >= c2) and 
       (((a3*(ex7_x)) + (b3*(ex7_y))) >= c3) and 
       (ex7_x >= 0) and (ex7_y >= 0)):
        value7 = (a*(ex7_x) + b*(ex7_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex7_x,ex7_y,value7))
        
    if((((a1*(ex8_x)) + (b1*(ex8_y))) >= c1) and 
       (((a2*(ex8_x)) + (b2*(ex8_y))) >= c2) and 
       (((a3*(ex8_x)) + (b3*(ex8_y))) >= c3) and 
       (ex8_x >= 0) and (ex8_y >= 0)):
        value8 = (a*(ex8_x) + b*(ex8_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex8_x,ex8_y,value8))
        
    if((((a1*(ex9_x)) + (b1*(ex9_y))) >= c1) and 
       (((a2*(ex9_x)) + (b2*(ex9_y))) >= c2) and 
       (((a3*(ex9_x)) + (b3*(ex9_y))) >= c3) and 
       (ex9_x >= 0) and (ex9_y >= 0)):
        value9 = (a*(ex9_x) + b*(ex9_y))
        print("Extreme points: (%d,%d) Value: %d" %(ex9_x,ex9_y,value9))
        
    if(c1<=0 and c2<=0 and c3<=0):
        value10 = 0
        print("Extreme points: (0,0) Value: 0")
        
    if(max1 >= value1):
        max1 = value1
        index = 1
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value2):
        max1 = value2
        index = 2
        if (max1 == value2 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value3):
        max1 = value3
        index = 3
        if (max1 == value3 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value4):
        max1 = value4
        index = 4
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value5):
        max1 = value5
        index = 5
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value6):
        max1 = value6
        index = 6
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value7):
        max1 = value7
        index = 7
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value8):
        max1 = value8
        index = 8
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value9):
        max1 = value9
        index = 9
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max1 >= value10):
        max1 = value10
        index = 0
        if (max1 == value1 and multi > 0):
            multi = multi +1
        else:
            multi = 1
        
    if(max == -1):
        print("No feasible region possible")
    else:
        if(multi > 1):
            print("Multiple minimum solutions")
        else:
            print("Unique minimum solution")
   
        if(index == 0):
            print("Minimum solution: x=0, y=0, value=0")
            
        if(index == 1):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex1_x,ex1_y,value1))
            
        if(index == 2):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex2_x,ex2_y,value2))
            
        if(index == 3):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex3_x,ex3_y,value3))
            
        if(index == 4):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex4_x,ex4_y,value4))
            
        if(index == 5):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex5_x,ex5_y,value5))
            
        if(index == 6):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex6_x,ex6_y,value6))
            
        if(index == 7):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex7_x,ex7_y,value7))
            
        if(index == 8):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex8_x,ex8_y,value8))
            
        if(index == 9):
            print("Minimum solution: x=%d, y=%d, value=%d" %(ex9_x,ex9_y,value9))
        


# In[ ]:




